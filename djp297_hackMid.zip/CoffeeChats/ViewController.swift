//
//  ViewController.swift
//  CoffeeChats
//
//  Created by daniel pati on 11/22/19.
//  Copyright © 2019 danielpati. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var collectionView: UICollectionView!
    
    var students: [Student] = []
    var paula: Student!
    var steven: Student!

    let studentCellReuseIdentifier = "studentCellReuseIdentifier"
    let padding: CGFloat = 16
    let headerHeight: CGFloat = 30

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Coffee Chats"
        view.backgroundColor = .white
        
        // Create Person objects
        paula = Student(schoolImageName: "cals", name: "Paula", year: "Freshmen")
        steven = Student(schoolImageName: "ilr", name: "Steven", year: "Junior")
        students = [paula, steven, paula, steven, paula, paula, paula, steven]

        // TODO: Setup collectionView
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = padding
        layout.minimumInteritemSpacing = padding
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .white
        collectionView.register(StudentCollectionViewCell.self, forCellWithReuseIdentifier: studentCellReuseIdentifier)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        view.addSubview(collectionView)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -400),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])
    }


}

extension ViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return students.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: studentCellReuseIdentifier, for: indexPath) as! StudentCollectionViewCell
        cell.configure(for: students[indexPath.row])
        return cell
    }

}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = (collectionView.frame.width - 36)
        return CGSize(width: size, height: size)
    }
    
}

